var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "./QueryBuilder", "./Field", "./FieldGroup"], function (require, exports, QueryBuilder_1, Field_1, FieldGroup_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ColumnType = QueryBuilder_1.ColumnType;
    var BaseModel = /** @class */ (function (_super) {
        __extends(BaseModel, _super);
        function BaseModel() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._fields = [];
            _this.validation = {};
            return _this;
        }
        BaseModel.prototype.prepareRecord = function (record) {
            return this.newInstance().createFromRecord(record);
        };
        BaseModel.prototype.prepareResult = function (result) {
            return this.newInstance().createFromResult(result);
        };
        BaseModel.prototype.getRecord = function (id) {
            return this.get(id, null, true);
        };
        BaseModel.prototype.setRecord = function (id, columns) {
            return this.get(id, columns, true);
        };
        BaseModel.prototype.createFromRecord = function (record) {
            var _this = this;
            this._record = record;
            if (this.columns)
                this.columns.forEach(function (column) {
                    _this.prepareField(column);
                });
            return this;
        };
        BaseModel.prototype.createFromResult = function (result) {
            var _this = this;
            this._record = result;
            if (result.columns)
                result.columns.forEach(function (column) {
                    var fieldId = _this.removePrefix(column.name);
                    _this.columns.push(fieldId);
                    _this.prepareField(fieldId);
                });
            return this;
        };
        BaseModel.prototype.exists = function (fieldId, value) {
            var model = this.newInstance();
            var exists = model.where(fieldId, '==', value)
                .first([]);
            return !!(exists);
        };
        BaseModel.prototype.first = function (columns) {
            var result = this.find(columns ? columns : this.columns);
            return result ? result.first() : null;
        };
        BaseModel.prototype.validateField = function (id) {
            return this.getField(id).validate();
        };
        BaseModel.prototype.validate = function () {
            return this._fields.every(function (field) {
                return field.validate();
            });
        };
        BaseModel.prototype.getValidationRules = function (fieldId) {
            var rules;
            try {
                rules = this.validation[fieldId];
            }
            catch (e) {
                // lol sorry
            }
            return rules;
        };
        BaseModel.prototype.newInstance = function () {
            var model = new BaseModel();
            // copy public properties
            model.recordType = this.recordType;
            model.columnPrefix = this.columnPrefix;
            model.typeMap = this.typeMap;
            model.validation = this.validation;
            model.relations = this.relations;
            return model;
        };
        BaseModel.prototype.prepareField = function (fieldId) {
            var nsField = this.getNsField(fieldId);
            var field = new Field_1.Field(fieldId, nsField, this._record)
                .setPrefix(this.dontPrefix.indexOf(fieldId) == -1 ? this.columnPrefix : '');
            var rules = this.getValidationRules(fieldId);
            if (rules)
                field.addRules(rules, this);
            this._fields.push(field);
            // Add Field to Model as a Param & Return
            return this[fieldId] = field;
        };
        BaseModel.prototype.getNsField = function (fieldId) {
            try {
                return this._record.getField({
                    fieldId: this.getColumnId(fieldId)
                });
            }
            catch (e) {
                return;
            }
        };
        BaseModel.prototype.removePrefix = function (fieldId) {
            return fieldId.replace(this.columnPrefix, '');
        };
        BaseModel.prototype.getField = function (fieldId) {
            return this.prepareField(fieldId);
        };
        BaseModel.prototype.getFields = function (fields) {
            var _this = this;
            var fieldGroup = FieldGroup_1.FieldGroup.create();
            fields.forEach(function (fieldId) {
                fieldGroup.push(_this.getField(fieldId));
            });
            return fieldGroup;
        };
        BaseModel.prototype.save = function () {
            this._record.save();
        };
        return BaseModel;
    }(QueryBuilder_1.QueryBuilder));
    exports.BaseModel = BaseModel;
});
