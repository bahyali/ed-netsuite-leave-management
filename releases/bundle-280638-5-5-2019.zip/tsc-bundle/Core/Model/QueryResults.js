var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var QueryResults = /** @class */ (function (_super) {
        __extends(QueryResults, _super);
        function QueryResults(results) {
            var _this = _super.apply(this, results) || this;
            _this._objects = [];
            return _this;
        }
        QueryResults.create = function () {
            return Object.create(QueryResults.prototype);
        };
        QueryResults.prototype.first = function () {
            return this[0] ?
                this[0] : null;
        };
        QueryResults.prototype.parse = function (results) {
            for (var i = 0; i < results.length; i++) {
                this._objects.push(results[i]);
            }
            return;
        };
        return QueryResults;
    }(Array));
    exports.QueryResults = QueryResults;
});
