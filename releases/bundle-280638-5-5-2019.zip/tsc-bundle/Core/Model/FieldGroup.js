var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var FieldGroup = /** @class */ (function (_super) {
        __extends(FieldGroup, _super);
        function FieldGroup(results) {
            return _super.apply(this, results) || this;
        }
        FieldGroup.create = function () {
            return Object.create(FieldGroup.prototype);
        };
        FieldGroup.prototype.disable = function (id) {
            if (id)
                this.find(id)[0].disabled = true;
            else
                this.makeAllDisabled(true);
        };
        FieldGroup.prototype.enable = function (id) {
            if (id)
                this.find(id)[0].disabled = false;
            else
                this.makeAllDisabled(false);
        };
        FieldGroup.prototype.required = function (id) {
            if (id)
                this.find(id)[0].mandatory = true;
            else
                this.makeAllMandatory(true);
        };
        FieldGroup.prototype.optional = function (id) {
            if (id)
                this.find(id)[0].mandatory = false;
            else
                this.makeAllMandatory(false);
        };
        FieldGroup.prototype.makeAllDisabled = function (value) {
            this.forEach(function (field) {
                field.disabled = value;
            });
        };
        FieldGroup.prototype.makeAllMandatory = function (value) {
            this.forEach(function (field) {
                field.mandatory = value;
            });
        };
        FieldGroup.prototype.persist = function (id) {
            if (id)
                this.find(id)[0].persist();
            else
                this.persistAll();
        };
        FieldGroup.prototype.persistAll = function () {
            this.forEach(function (field) {
                field.persist();
            });
        };
        FieldGroup.prototype.saveState = function () {
            var states = {};
            this.forEach(function (field) {
                states[field._id] = field.saveState();
            });
            return states;
        };
        FieldGroup.prototype.setState = function (states) {
            var _this = this;
            Object.keys(states).forEach(function (key) {
                var field = _this.find(key)[0];
                field.setState(states[key]);
            });
        };
        FieldGroup.prototype.remove = function (id) {
            var index = this.find(id).length > 0 ? this.indexOf(this.find(id)[0]) : -1;
            if (index !== -1)
                this.splice(index, 1);
        };
        FieldGroup.prototype.getField = function (id) {
            var filter = this.filter(function (obj) { return obj._id == id; });
            return filter.length > 0 ? filter[0] : null;
        };
        FieldGroup.prototype.find = function (id) {
            return this.filter(function (obj) { return obj._id == id; });
        };
        return FieldGroup;
    }(Array));
    exports.FieldGroup = FieldGroup;
});
