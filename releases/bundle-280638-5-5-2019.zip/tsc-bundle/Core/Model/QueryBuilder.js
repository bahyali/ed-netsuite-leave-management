define(["require", "exports", "./Operator", "./QueryResults", "N/search", "N/record"], function (require, exports, Operator_1, QueryResults_1, search, record) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var ColumnType;
    (function (ColumnType) {
        ColumnType["STRING"] = "string";
        ColumnType["BOOLEAN"] = "boolean";
        ColumnType["NUMBER"] = "number";
        ColumnType["DATE"] = "date";
        ColumnType["LIST"] = "list";
        ColumnType["MULTI"] = "multi";
    })(ColumnType = exports.ColumnType || (exports.ColumnType = {}));
    var QueryBuilder = /** @class */ (function () {
        function QueryBuilder() {
            this.recordType = '';
            this.primaryKey = 'id';
            this.typeMap = {};
            this.columnPrefix = '';
            this.columns = [];
            this.dontPrefix = [
                'id',
                'name',
                'internalid',
                'isinactive'
            ];
            this._limit = 999;
            this._query = [];
        }
        QueryBuilder.prototype.get = function (recordId, columns, load) {
            if (!load)
                return this.prepareResult(search.lookupFields({
                    type: this.recordType,
                    id: recordId,
                    columns: columns ? this.prepareColumns(columns) : this.prepareColumns(this.columns),
                }));
            return this.prepareRecord(record.load({ id: recordId, type: this.recordType, isDynamic: false }));
        };
        QueryBuilder.prototype.find = function (columns) {
            var results = search.create({
                type: this.recordType,
                filters: this._query,
                columns: columns ? this.prepareColumns(columns) : this.prepareColumns(this.columns),
            }).run()
                .getRange({ start: 0, end: this._limit });
            return this.prepareResults(results);
        };
        QueryBuilder.prototype.query = function () {
            return false;
        };
        QueryBuilder.prototype.where = function (columnId, operator, value, summary) {
            if (value === void 0) { value = null; }
            // Validate here
            var nsOperator = Operator_1.Operator.get(operator, this.getColumnType(columnId));
            var options = {
                name: this.getColumnId(columnId),
                operator: nsOperator
            };
            if (value)
                options['values'] = value;
            if (summary)
                options['summary'] = summary;
            this._query.push(search.createFilter(options));
            return this;
        };
        QueryBuilder.prototype.limit = function (limit) {
            this._limit = limit;
            return this;
        };
        QueryBuilder.prototype.prepareColumns = function (columns) {
            columns = this.addPrefix(columns);
            // Add primary key : Important for integrity
            // columns.push(this.primaryKey);
            return columns;
        };
        QueryBuilder.prototype.prepareRecord = function (record) {
            return record;
        };
        QueryBuilder.prototype.prepareResult = function (result) {
            return result;
        };
        QueryBuilder.prototype.prepareResults = function (results) {
            var records = QueryResults_1.QueryResults.create();
            for (var i = 0; i < results.length; i++) {
                records.push(this.prepareResult(results[i]));
            }
            return records;
        };
        QueryBuilder.prototype.getColumnType = function (column) {
            return this.typeMap[column];
        };
        QueryBuilder.prototype.getColumnId = function (column) {
            if (this.dontPrefix.indexOf(column) !== -1)
                return column;
            return this.columnPrefix + column;
        };
        QueryBuilder.prototype.addPrefix = function (columns) {
            var prefixed = [];
            for (var i = 0; i < columns.length; i++)
                prefixed.push(this.getColumnId(columns[i]));
            return prefixed;
        };
        return QueryBuilder;
    }());
    exports.QueryBuilder = QueryBuilder;
});
