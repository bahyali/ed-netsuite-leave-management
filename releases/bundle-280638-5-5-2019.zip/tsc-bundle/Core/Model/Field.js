define(["require", "exports", "../Validation"], function (require, exports, Validation_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var Field = /** @class */ (function () {
        function Field(id, field, record) {
            this._rules = [];
            this._id = id;
            this._field = field;
            if (field)
                this._fieldId = field.id;
            if (record) {
                this._record = record;
            }
        }
        Field.prototype.setPrefix = function (prefix) {
            this._fieldId = prefix + this._id;
            return this;
        };
        Field.prototype.addRules = function (fieldValidations, model) {
            var _this = this;
            var $self = this;
            fieldValidations.forEach(function (rule) {
                _this._rules.push(new Validation_1.Rule(rule, $self, model));
            });
            return this;
        };
        Field.prototype.validate = function () {
            return this._rules.every(function (rule) {
                return rule.validate();
            });
        };
        Field.prototype.disable = function (disabled) {
            if (disabled === void 0) { disabled = true; }
            this.disabled = disabled;
        };
        Field.prototype.makeMandatory = function () {
            this.mandatory = true;
        };
        Object.defineProperty(Field.prototype, "value", {
            get: function () {
                if (!this._record)
                    return;
                return this._value = this._record.getValue(this._fieldId);
            },
            set: function (value) {
                if (!this._record)
                    return;
                this._value = value;
                this._record.setValue(this._fieldId, value);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "text", {
            get: function () {
                if (!this._record)
                    return;
                return this._text = this._record.getText(this._fieldId).toString();
            },
            set: function (text) {
                if (!this._record)
                    return;
                this._text = text;
                this._record.setText(this._fieldId, text);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "disabled", {
            get: function () {
                return this._disabled = this._field.isDisabled;
            },
            set: function (value) {
                this._disabled = value;
                this._field.isDisabled = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "mandatory", {
            get: function () {
                return this._mandatory = this._field.isMandatory;
            },
            set: function (value) {
                this._mandatory = value;
                this._field.isMandatory = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "visible", {
            get: function () {
                return this._hidden = this._field.isVisible;
            },
            set: function (value) {
                this._hidden = value;
                this._field.isVisible = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "readOnly", {
            get: function () {
                return this._readOnly = this._field.isReadOnly;
            },
            set: function (value) {
                this._readOnly = value;
                this._field.isReadOnly = value;
            },
            enumerable: true,
            configurable: true
        });
        Field.prototype.persist = function () {
            if (typeof this._mandatory !== 'undefined')
                this.mandatory = this._mandatory;
            if (typeof this._disabled !== 'undefined')
                this.disabled = this._disabled;
            if (typeof this._readOnly !== 'undefined')
                this.readOnly = this._readOnly;
        };
        Field.prototype.saveState = function () {
            return {
                disabled: this.disabled,
                mandatory: this.mandatory,
                readonly: this.readOnly
            };
        };
        Field.prototype.setState = function (obj) {
            if (typeof obj['disabled'] !== 'undefined')
                this.disabled = obj['disabled'];
            if (typeof obj['mandatory'] !== 'undefined')
                this.mandatory = obj['mandatory'];
            if (typeof obj['readOnly'] !== 'undefined')
                this.readOnly = obj['readOnly'];
        };
        return Field;
    }());
    exports.Field = Field;
});
