define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var Rule = /** @class */ (function () {
        function Rule(validator, field, model) {
            this._validator = validator;
            this._type = Rule.setRuleType(validator);
            this._field = field;
            this._model = model;
        }
        Rule.setRuleType = function (validator) {
            if (typeof validator == 'string')
                // _Field only required to function
                return 0 /* String */;
            else if (typeof validator == 'object')
                return 1 /* Object */;
            else if (validator instanceof Function)
                return 2 /* Callback */;
        };
        Rule.prototype.validate = function () {
            //dependencies to inject in all validators
            var args = [this._field, this._model];
            if (this._type == 0 /* String */) {
                // String validation on Field Value
                return Validation[this._validator].apply(Validation, args)();
            }
            else if (this._type == 1 /* Object */) {
                // Parse Object and Extract Data
                //{ validatorName: [arg1, arg2, arg3] };
                var validator = Object.keys(this._validator)[0];
                args.push.apply(args, this._validator[validator]);
                return Validation[validator].apply(Validation, args)();
            }
            else if (this._type == 2 /* Callback */)
                // Run Function
                //()=> {return boolean}
                return this._validator.apply(this, args);
            // If no validators could run, it should be valid.
            return true;
        };
        return Rule;
    }());
    exports.Rule = Rule;
    // Our validation layer
    var Validation = /** @class */ (function () {
        function Validation() {
        }
        Validation.isEmpty = function (field) {
            return function () { return field.value.toString().length == 0; };
        };
        Validation.isNotEmpty = function (field) {
            return function () { return field.value.toString().length > 0; };
        };
        Validation.isUnique = function (field, model) {
            return function () { return !model.exists(field._id, field.value); };
        };
        Validation.exists = function (field, model) {
            return function () { return model.exists(field._id, field.value); };
        };
        Validation.greaterThan = function (field, model, otherFieldId) {
            return function () {
                var otherFieldValue = model.getField(otherFieldId).value;
                var fieldValue = field.value;
                return fieldValue > otherFieldValue;
            };
        };
        Validation.lessThan = function (field, model, otherFieldId) {
            var _this = this;
            return function () { return !_this.greaterThan(field, model, otherFieldId)(); };
        };
        Validation.greaterThanOrEqual = function (field, model, otherFieldId) {
            return function () { return field.value >= model.getField(otherFieldId).value; };
        };
        Validation.lessThanOrEqual = function (field, model, otherFieldId) {
            return function () { return field.value <= model.getField(otherFieldId).value; };
        };
        return Validation;
    }());
    exports.Validation = Validation;
});
