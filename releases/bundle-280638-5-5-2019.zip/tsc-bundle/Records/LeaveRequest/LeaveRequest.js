/**
 * @module      LeaveManagement
 * @class       LeaveRequest
 * @description `LeaveRequest` class extends `BaseModel` class to prepare a Vacation Request and access employee's vacations balance.
 * @author      Mohamed Elshowel
 * @version     1.0.0
 * @repo        https://github.com/bahyali/ed-netsuite-leave-management
 * @NApiVersion 2.0
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "../../Core/Model/BaseModel", "../LeaveType/LeaveType", "../LeaveRule/LeaveRule", "../Employee/Employee"], function (require, exports, BaseModel_1, LeaveType_1, LeaveRule_1, Employee_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    // import { FieldGroup } from '../../Core/Model/FieldGroup';
    /** Defining the Fields in Vacation Request Record */
    var EmployeeField;
    (function (EmployeeField) {
        EmployeeField["EMPLOYEE"] = "emp_name";
        EmployeeField["SUBSIDIARY"] = "subsidiary";
        EmployeeField["SUPERVISOR"] = "supervisor";
        EmployeeField["DEPARTMENT"] = "department";
        EmployeeField["JOBTITLE"] = "jobtitle";
    })(EmployeeField = exports.EmployeeField || (exports.EmployeeField = {}));
    var BalanceField;
    (function (BalanceField) {
        BalanceField["ANNUAL"] = "blc_annual";
        BalanceField["TRANSFERRED"] = "blc_transferred";
        BalanceField["REPLACEMENT"] = "blc_replacement";
        BalanceField["CASUAL"] = "blc_casual";
        BalanceField["SICK"] = "blc_sick";
        BalanceField["TOTAL_REGULAR"] = "blc_total_regular";
        BalanceField["UNPAID"] = "blc_unpaid";
    })(BalanceField = exports.BalanceField || (exports.BalanceField = {}));
    var RequestField;
    (function (RequestField) {
        RequestField["TYPE"] = "type";
        RequestField["START"] = "start";
        RequestField["END"] = "end";
        RequestField["LEAVE_DAYS"] = "leave_days";
        RequestField["PART_DAY_LEAVE"] = "leave_partday";
        RequestField["REQUEST_DATE"] = "date";
        RequestField["STATUS"] = "status";
    })(RequestField = exports.RequestField || (exports.RequestField = {}));
    var RelationField;
    (function (RelationField) {
        RelationField["BALANCE"] = "vac_blc";
        RelationField["RULE_CASUAL_FROM_ANNUAL"] = "rule_cas_as_ann";
        RelationField["RULE_APPLY_WEEKEND"] = "rule_weekend_app";
        RelationField["RULE_WEEKENDS"] = "rule_weekend_days";
        RelationField["TYPE_MAPPING"] = "type_mapping";
        RelationField["TYPE_LIMIT_DAYS"] = "type_dayslimit";
        RelationField["TYPE_MAX_PER_REQUEST"] = "type_max_days_req";
        RelationField["TYPE_FREQUENT_TYPE"] = "type_freq_type";
        RelationField["TYPE_FREQUENT_VALUE"] = "type_freq_value";
        RelationField["TYPE_ACCEPT_PAST_DATES"] = "type_accept_past";
    })(RelationField = exports.RelationField || (exports.RelationField = {}));
    var LeaveRequest = /** @class */ (function (_super) {
        __extends(LeaveRequest, _super);
        function LeaveRequest() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.recordType = 'customrecord_edc_vac_request';
            _this.columnPrefix = 'custrecord_edc_vac_req_';
            _this.typeMap = {
                // Employee's Information
                'emp_name': BaseModel_1.ColumnType.LIST,
                'subsidiary': BaseModel_1.ColumnType.LIST,
                'supervisor': BaseModel_1.ColumnType.LIST,
                'department': BaseModel_1.ColumnType.LIST,
                'jobtitle': BaseModel_1.ColumnType.STRING,
                // Employee's Balance
                'blc_annual': BaseModel_1.ColumnType.NUMBER,
                'blc_transferred': BaseModel_1.ColumnType.NUMBER,
                'blc_replacement': BaseModel_1.ColumnType.NUMBER,
                'blc_casual': BaseModel_1.ColumnType.NUMBER,
                'blc_sick': BaseModel_1.ColumnType.NUMBER,
                'blc_total_regular': BaseModel_1.ColumnType.NUMBER,
                'blc_unpaid': BaseModel_1.ColumnType.NUMBER,
                // Request Field
                'type': BaseModel_1.ColumnType.LIST,
                'start': BaseModel_1.ColumnType.DATE,
                'end': BaseModel_1.ColumnType.DATE,
                'leave_days': BaseModel_1.ColumnType.NUMBER,
                'leave_partday': BaseModel_1.ColumnType.LIST,
                // Other Fields
                'date': BaseModel_1.ColumnType.DATE,
                'time': BaseModel_1.ColumnType.NUMBER,
                'status': BaseModel_1.ColumnType.LIST,
            };
            _this.balanceColumns = [];
            _this.columns = [];
            _this.validation = {
                'type': ['isNotEmpty'],
                'start': [],
                'end': [],
            };
            _this.relations = {
                getEmployee: function (model) {
                    return new Employee_1.Employee()
                        .setRecord(model.getField(EmployeeField.EMPLOYEE).value);
                },
                leaveRule: function (subsidiary, year) {
                    if (year === void 0) { year = new Date().getFullYear(); }
                    return new LeaveRule_1.LeaveRule()
                        .where(LeaveRule_1.LeaveRuleField.SUBSIDIARY, '==', subsidiary)
                        .where(LeaveRule_1.LeaveRuleField.YEAR, '==', year);
                },
                leaveType: function (model) {
                    var leaveTypeId = model.getField(RequestField.TYPE).value;
                    return new LeaveType_1.LeaveType()
                        .where(LeaveType_1.LeaveTypeFields.MAPPING, '==', leaveTypeId);
                }
            };
            return _this;
        }
        return LeaveRequest;
    }(BaseModel_1.BaseModel));
    exports.LeaveRequest = LeaveRequest;
});
