/**
 * @NScriptName ClientScript Vacation Request
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(["require", "exports", "N/ui/message", "./LeaveRequest", "../helpers", "../LeaveRule/LeaveRule", "../LeaveType/LeaveType", "../Holiday/Holiday"], function (require, exports, UIMessage, LeaveRequest_1, helpers_1, LeaveRule_1, LeaveType_1, Holiday_1) {
    // Global Variables
    var employee;
    var leaveBalance;
    var leaveType;
    var balances;
    var leavePeriod;
    var leaveRequest = new LeaveRequest_1.LeaveRequest();
    var leaveRule;
    var holidays;
    // Filling the Balance Columns
    Object.keys(LeaveRequest_1.BalanceField).forEach(function (key) { return leaveRequest.balanceColumns.push(LeaveRequest_1.BalanceField[key]); });
    var StandardLeaveType;
    (function (StandardLeaveType) {
        StandardLeaveType["ANNUAL"] = "annual";
        StandardLeaveType["CASUAL"] = "casual";
        StandardLeaveType["SICK"] = "sick";
        StandardLeaveType["UNPAID"] = "unpaid";
        StandardLeaveType["REPLACEMENT"] = "replacement";
        StandardLeaveType["TRANSFERRED"] = "transferred";
        StandardLeaveType["CUSTOM"] = "custom";
    })(StandardLeaveType || (StandardLeaveType = {}));
    // Pushing Custom Validations to record fields
    leaveRequest.validation['start'].push(function (field, model) {
        return true;
    });
    function pageInit(context) {
        leaveRequest.createFromRecord(context.currentRecord);
        leaveRequest.columns = [
            LeaveRequest_1.EmployeeField.EMPLOYEE
        ];
        // set type
        var typeField = leaveRequest.getField(LeaveRequest_1.RequestField.TYPE);
        leaveType = leaveRequest.relations.leaveType(leaveRequest)
            .setRecord(typeField.value);
        // get employee balance
        // Inject relationship dependency by hand now till we find a better way
        employee = leaveRequest.relations
            .getEmployee(leaveRequest);
        // OR:
        // employee = runtime.getCurrentUser().id;
        leaveBalance = employee.relations
            .vacationBalance(employee, new Date().getFullYear());
        // Init LeaveRule
        leaveRule = leaveRequest.relations
            .leaveRule(Number(leaveRequest.getField('subsidiary').value)).first();
        holidays = new Holiday_1.Holiday()
            .where('isinactive', 'is', 'F')
            .find(['date']);
        balances = leaveBalance.first([
            'annual',
            'replacement',
            'transferred',
            'casual',
            'sick',
            'unpaid',
            'total_regular'
        ]);
        debugger;
        if (balances)
            initCounters(leaveRequest, balances);
        else {
            leaveRequest.getFields([LeaveRequest_1.RequestField.TYPE, LeaveRequest_1.RequestField.START, LeaveRequest_1.RequestField.END]).disable();
            helpers_1.UI.showMessage('Warning', 'No vacation balance for this employee', 0, UIMessage.Type.INFORMATION);
        }
    }
    function validateField(context) {
        leaveRequest.createFromRecord(context.currentRecord);
        var field = leaveRequest.getField(leaveRequest.removePrefix(context.fieldId));
        var valid = field.validate();
        if (!valid) {
            helpers_1.UI.showMessage('Warning', 'Field: ' + field._id.replace('_', ' ').toUpperCase() + ' is invalid!');
            return false;
        }
        if (field.value && field._id == LeaveRequest_1.RequestField.TYPE) {
            leaveType = leaveRequest.relations
                .leaveType(leaveRequest)
                .setRecord(field.value);
            partDayLeave(leaveType, leaveRequest.getField(LeaveRequest_1.RequestField.START).value, leaveRequest.getField(LeaveRequest_1.RequestField.END).value);
            if (!leaveType) {
                helpers_1.UI.showMessage('Warning', 'Vacation doesn\'t exist?');
                return false;
            }
            else {
                // Empty the Start & End Date Fields
                // leaveRequest.getField(RequestField.START).value = '';
                // leaveRequest.getField(RequestField.END).value = '';
                initCounters(leaveRequest, balances);
                updateCounters();
            }
        }
        else if (field._id == LeaveRequest_1.RequestField.START || field._id == LeaveRequest_1.RequestField.END) {
            var type = leaveType.getField(LeaveType_1.LeaveTypeFields.MAPPING).text.toString().toLowerCase();
            var startDate = leaveRequest.getField(LeaveRequest_1.RequestField.START).value;
            var endDate = leaveRequest.getField(LeaveRequest_1.RequestField.END).value;
            if (type == StandardLeaveType.CUSTOM && startDate && endDate) {
                valid = calculateCustomLeave(leaveType, startDate, endDate);
            }
        }
        return valid;
    }
    function fieldChanged(context) {
        leaveRequest.createFromRecord(context.currentRecord);
        var field = leaveRequest.getField(leaveRequest.removePrefix(context.fieldId));
        if (field.value && field._id == LeaveRequest_1.RequestField.TYPE) {
        }
        if (field._id == LeaveRequest_1.RequestField.START || field._id == LeaveRequest_1.RequestField.END) {
            if (field._id == LeaveRequest_1.RequestField.START)
                leavePeriod = calculateVacation(leaveType, field.value, leaveRequest.getField(LeaveRequest_1.RequestField.END).value);
            else if (field._id == LeaveRequest_1.RequestField.END)
                leavePeriod = calculateVacation(leaveType, leaveRequest.getField(LeaveRequest_1.RequestField.START).value, field.value);
            updateCounters();
        }
        if (field._id == LeaveRequest_1.RequestField.PART_DAY_LEAVE) {
            var partDayPeriod = Number(leaveRequest.getField(LeaveRequest_1.RequestField.PART_DAY_LEAVE).text);
            if (partDayPeriod) {
                leavePeriod = partDayPeriod;
                updateCounters();
            }
        }
    }
    function saveRecord(context) {
        return true;
    }
    function calculateVacation(vacationType, start, end) {
        var startDate = new Date(start);
        var endDate = new Date(end);
        if (!startDate || !endDate)
            return 0;
        partDayLeave(vacationType, start, end);
        // Get Vacation Rule to extract the weekend days from it.
        var applyWeekend = leaveRule.getField(LeaveRule_1.LeaveRuleField.APPLY_WEEKEND).value;
        if (applyWeekend) {
            var weekends = leaveRule.getField(LeaveRule_1.LeaveRuleField.WEEKEND_DAYS).value;
            var holidayDates = holidays.map(function (item) {
                var date = item.getField('date').value.split('/');
                return new Date(date[2], date[1] - 1, date[0]);
            });
            // Map day ids to day numbers
            var mappedWeekends = weekends.split(',').map(function (item) {
                if (item == '1') //Friday
                    return 5;
                else if (item == '2') //Saturday
                    return 6;
                else if (item == '3') //Sunday
                    return 0;
            });
            return helpers_1.Model.getWorkingDays(start, end, mappedWeekends, holidayDates);
        }
        return helpers_1.Model.getWorkingDays(startDate, endDate, []);
    }
    function updateCounters() {
        if (leavePeriod == undefined)
            return false;
        // Update Leave Days
        leaveRequest.getField('leave_days').value = leavePeriod;
        // Update Counter
        var typeMap = leaveType.getField('mapping').text.toString().toLowerCase();
        var empBalanceField = balances.getField(typeMap);
        var reqBalanceField = leaveRequest.getField('blc_' + typeMap);
        switch (typeMap) {
            case StandardLeaveType.CUSTOM:
                break;
            case StandardLeaveType.UNPAID:
                reqBalanceField.value = Number(empBalanceField.value) + leavePeriod;
                break;
            case StandardLeaveType.ANNUAL:
                deductRegularVacation();
                break;
            case StandardLeaveType.CASUAL:
                var deductCasualFromAnnual = Boolean(leaveRule
                    .getField(LeaveRule_1.LeaveRuleField.DEDUCT_CAUSUAL_FROM_ANNUAL).value);
                if (deductCasualFromAnnual)
                    deductRegularVacation();
            default:
                reqBalanceField.value = empBalanceField.value - leavePeriod;
                if (empBalanceField.value - leavePeriod < 0) {
                    helpers_1.UI.showMessage('Warning', 'No vacation balance.');
                }
                break;
        }
    }
    function initCounters(leaveRequest, balance) {
        var prefix = 'blc_';
        var fields = balance.getFields(balance.columns);
        fields.forEach(function (field) {
            var $field = leaveRequest.getField(prefix + field._id);
            $field.value = field.value;
        });
    }
    function deductRegularVacation() {
        var annualField = leaveRequest.getField(LeaveRequest_1.BalanceField.ANNUAL);
        var transferredField = leaveRequest.getField(LeaveRequest_1.BalanceField.TRANSFERRED);
        var replacementField = leaveRequest.getField(LeaveRequest_1.BalanceField.REPLACEMENT);
        transferredField.value = balances.transferred.value - leavePeriod;
        if (transferredField.value < 0) {
            replacementField.value = balances.replacement.value - Math.abs(transferredField.value);
            transferredField.value = 0;
            if (replacementField.value < 0) {
                annualField.value = balances.annual.value - Math.abs(replacementField.value);
                replacementField.value = 0;
                if (annualField.value < 0) {
                    helpers_1.UI.showMessage('Warning', 'No vacation balance!');
                }
            }
        }
    }
    function partDayLeave(leaveType, start, end) {
        var startDate = new Date(start);
        var endDate = new Date(end);
        if (leaveType.getField('mapping').text.toString().toLowerCase() == StandardLeaveType.ANNUAL) {
            if (startDate.getTime() == endDate.getTime()) {
                var daysLeave = leaveRequest.getField(LeaveRequest_1.RequestField.LEAVE_DAYS);
                daysLeave.value = '';
                daysLeave.visible = false;
                var partdayPeriod = leaveRequest.getField(LeaveRequest_1.RequestField.PART_DAY_LEAVE);
                partdayPeriod.text = '1';
                partdayPeriod.disabled = false;
            }
        }
        if (startDate < endDate || !startDate && !endDate) {
            var daysLeave = leaveRequest.getField(LeaveRequest_1.RequestField.LEAVE_DAYS);
            daysLeave.value = helpers_1.Model.millisecondsToHuman(endDate.getTime() - startDate.getTime()).days + 1;
            daysLeave.visible = true;
            var partdayPeriod = leaveRequest.getField(LeaveRequest_1.RequestField.PART_DAY_LEAVE);
            partdayPeriod.value = '';
            partdayPeriod.disabled = true;
        }
    }
    function calculateCustomLeave(leaveType, startDate, endDate) {
        var maxAllowedDays = Number(leaveType.getField(LeaveType_1.LeaveTypeFields.DAYS_LIMIT).value);
        var maxDaysPerRequest = Number(leaveType.getField(LeaveType_1.LeaveTypeFields.MAX_DAYS_REQUEST).value);
        var frequentValue = Number(leaveType.getField(LeaveType_1.LeaveTypeFields.FREQUENT_VALUE).value);
        var frequentTypeText = leaveType.getField(LeaveType_1.LeaveTypeFields.FREQUENT_TYPE).text.toLowerCase();
        leavePeriod = helpers_1.Model.millisecondsToHuman(new Date(endDate).getTime() - new Date(startDate).getTime()).days + 1;
        if (maxDaysPerRequest && leavePeriod > maxDaysPerRequest)
            return false;
        var requestDate = new Date(leaveRequest.getField(LeaveRequest_1.RequestField.REQUEST_DATE).value.toString());
        var previousApprovedRequests = new LeaveRequest_1.LeaveRequest()
            .where(LeaveRequest_1.EmployeeField.EMPLOYEE, '==', leaveRequest.getField(LeaveRequest_1.EmployeeField.EMPLOYEE).value)
            .where(LeaveRequest_1.RequestField.TYPE, '==', leaveRequest.getField(LeaveRequest_1.RequestField.TYPE).value)
            .where(LeaveRequest_1.RequestField.STATUS, '==', helpers_1.ApprovalStatus.APPROVED);
        if (frequentValue && frequentTypeText) {
            if (frequentTypeText == helpers_1.PeriodFrequentType.Days) {
                requestDate.setDate(requestDate.getDate() - frequentValue);
                previousApprovedRequests.where(LeaveRequest_1.RequestField.START, 'after', helpers_1.Model.toNSDateString(requestDate));
            }
            else if (frequentTypeText == helpers_1.PeriodFrequentType.Months) {
                requestDate.setDate(1);
                requestDate.setMonth(requestDate.getMonth() - frequentValue);
                previousApprovedRequests.where(LeaveRequest_1.RequestField.START, 'after', helpers_1.Model.toNSDateString(requestDate));
            }
            else if (frequentTypeText == helpers_1.PeriodFrequentType.Years) {
                requestDate.setDate(1);
                requestDate.setMonth(0);
                requestDate.setFullYear(requestDate.getFullYear() - frequentValue);
                previousApprovedRequests.where(LeaveRequest_1.RequestField.START, 'after', helpers_1.Model.toNSDateString(requestDate));
            }
            var previousLeaveDays = previousApprovedRequests.find([LeaveRequest_1.RequestField.LEAVE_DAYS]);
            if (frequentTypeText == helpers_1.PeriodFrequentType.Lifetime) {
                if (previousLeaveDays && previousLeaveDays.length >= frequentValue)
                    return false;
            }
            if (previousLeaveDays && previousLeaveDays.length) {
                var totalPreviousLeaves = 0;
                for (var i = 0; i < previousLeaveDays.length; i++) {
                    totalPreviousLeaves += Number(previousLeaveDays[i][LeaveRequest_1.RequestField.LEAVE_DAYS]);
                }
                if (totalPreviousLeaves >= maxAllowedDays)
                    return false;
            }
            //if(previousLeaveDays[''] >=  maxAllowedDays)
            //return false;
        }
        return true;
    }
    return {
        pageInit: pageInit,
        validateField: validateField,
        fieldChanged: fieldChanged,
        saveRecord: saveRecord
    };
});
