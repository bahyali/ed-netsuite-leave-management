/**
 * @NScriptName UserEvent - Vacation Request
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(["require", "exports", "./LeaveRequest", "../helpers", "../LeaveBalance/LeaveBalance", "N/search"], function (require, exports, LeaveRequest_1, helpers_1, LeaveBalance_1, search) {
    function beforeLoad(context) {
        if (context.type !== context.UserEventType.CREATE)
            return;
        var leaveRequest = new LeaveRequest_1.LeaveRequest()
            .createFromRecord(context.newRecord);
        // Get Saved Search [My Vacation Balances]
        var myVacationBalances = search.load({
            id: 'customsearch_edc_lm_vac_blc'
        }).run()
            .getRange({ end: 1, start: 0 });
        // If results
        if (myVacationBalances.length > 0) {
            var leaveBalance = myVacationBalances[0];
            leaveRequest.getField('vac_blc').value = leaveBalance.getValue('internalid');
        }
        var leaveRule = leaveRequest.relations
            .leaveRule(Number(leaveRequest.getField('subsidiary').value))
            .first(['internalid']);
        if (leaveRule)
            leaveRequest.getField('rule_link').value = leaveRule.getField('internalid').value;
    }
    function beforeSubmit(context) {
        var leaveRequest = new LeaveRequest_1.LeaveRequest()
            .createFromRecord(context.newRecord);
        var requestStatus = leaveRequest.getField(LeaveRequest_1.RequestField.STATUS).value;
        if (requestStatus == helpers_1.ApprovalStatus.APPROVED) {
            var balanceRecordId = Number(leaveRequest.getField(LeaveRequest_1.RelationField.BALANCE).value);
            var leaveBalance = new LeaveBalance_1.LeaveBalance().setRecord(balanceRecordId);
            leaveBalance.getField(LeaveBalance_1.LeaveBalanceField.ANNUAL).value = Number(leaveRequest.getField(LeaveRequest_1.BalanceField.ANNUAL).value);
            leaveBalance.getField(LeaveBalance_1.LeaveBalanceField.TRANSFERRED).value = Number(leaveRequest.getField(LeaveRequest_1.BalanceField.TRANSFERRED).value);
            leaveBalance.getField(LeaveBalance_1.LeaveBalanceField.REPLACEMENT).value = Number(leaveRequest.getField(LeaveRequest_1.BalanceField.REPLACEMENT).value);
            leaveBalance.getField(LeaveBalance_1.LeaveBalanceField.CASUAL).value = Number(leaveRequest.getField(LeaveRequest_1.BalanceField.CASUAL).value);
            leaveBalance.getField(LeaveBalance_1.LeaveBalanceField.SICK).value = Number(leaveRequest.getField(LeaveRequest_1.BalanceField.SICK).value);
            leaveBalance.getField(LeaveBalance_1.LeaveBalanceField.UNPAID).value = Number(leaveRequest.getField(LeaveRequest_1.BalanceField.UNPAID).value);
            leaveBalance.save();
        }
    }
    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
    };
});
