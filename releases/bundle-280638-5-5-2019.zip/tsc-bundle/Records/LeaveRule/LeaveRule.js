/**
 * @module      LeaveManagement
 * @class       LeaveRule
 * @description `LeaveRule` class extends `BaseModel` class to prepare a Vacation Request and access employee's vacations balance.
 * @author      Mohamed Elshowel
 * @version     1.0.0
 * @repo        https://github.com/bahyali/ed-netsuite-leave-management
 * @NApiVersion 2.0
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "../../Core/Model/BaseModel"], function (require, exports, BaseModel_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var LeaveRuleField;
    (function (LeaveRuleField) {
        LeaveRuleField["SUBSIDIARY"] = "subsidiary";
        LeaveRuleField["YEAR"] = "year";
        LeaveRuleField["DEDUCT_CAUSUAL_FROM_ANNUAL"] = "casual_as_annual";
        LeaveRuleField["APPLY_WEEKEND"] = "weekend_apply";
        LeaveRuleField["WEEKEND_DAYS"] = "weekend_days";
        LeaveRuleField["PERMISSION_HOURS"] = "permission_hours";
    })(LeaveRuleField = exports.LeaveRuleField || (exports.LeaveRuleField = {}));
    var LeaveRule = /** @class */ (function (_super) {
        __extends(LeaveRule, _super);
        function LeaveRule() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.recordType = 'customrecord_edc_vac_rule';
            _this.columnPrefix = 'custrecord_edc_vac_rule_';
            _this.typeMap = {
                'subsidiary': BaseModel_1.ColumnType.LIST,
                'casual_as_annual': BaseModel_1.ColumnType.BOOLEAN,
                'weekend_apply': BaseModel_1.ColumnType.BOOLEAN,
                'weekend_days': BaseModel_1.ColumnType.MULTI,
                'year': BaseModel_1.ColumnType.STRING,
            };
            _this.columns = Object.keys(_this.typeMap);
            _this.validation = {
                'subsidiary': [],
                'weekend_apply': [],
            };
            return _this;
        }
        return LeaveRule;
    }(BaseModel_1.BaseModel));
    exports.LeaveRule = LeaveRule;
});
