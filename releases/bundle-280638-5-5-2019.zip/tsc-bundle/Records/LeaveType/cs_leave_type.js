/**
 * @NScriptName ClientScript Vacation Types
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(["require", "exports", "./LeaveType", "../helpers"], function (require, exports, LeaveType_1, helpers_1) {
    var showMessage = helpers_1.UI.showMessage;
    var stack = [];
    var leaveType = new LeaveType_1.LeaveType();
    leaveType.columns = [
        LeaveType_1.LeaveTypeFields.DAYS_LIMIT,
        LeaveType_1.LeaveTypeFields.MAX_DAYS_REQUEST,
        LeaveType_1.LeaveTypeFields.FREQUENT_TYPE,
        LeaveType_1.LeaveTypeFields.FREQUENT_VALUE
    ];
    function pageInit(context) {
        leaveType.createFromRecord(context.currentRecord);
        if (context.mode == 'edit') {
            // Getting the text of the item selected in "Mapping" DropDownList Field.
            var mapping = leaveType.getField(LeaveType_1.LeaveTypeFields.MAPPING);
            if (mapping.text.toString().toLowerCase() !== 'custom')
                mapping.disable();
        }
    }
    function fieldChanged(context) {
        leaveType.createFromRecord(context.currentRecord);
        if (context.fieldId == leaveType.getColumnId(LeaveType_1.LeaveTypeFields.FREQUENT_TYPE)) {
            var frequentType = leaveType.getField(LeaveType_1.LeaveTypeFields.FREQUENT_TYPE).value;
            leaveType.getField(LeaveType_1.LeaveTypeFields.FREQUENT_VALUE).disabled = !(frequentType);
            leaveType.getField(LeaveType_1.LeaveTypeFields.FREQUENT_VALUE).mandatory = !!(frequentType);
        }
    }
    function validateField(context) {
        leaveType.createFromRecord(context.currentRecord);
        var field = leaveType.getField(leaveType.removePrefix(context.fieldId));
        var valid = field ? field.validate() : true;
        if (context.fieldId == leaveType.getColumnId(LeaveType_1.LeaveTypeFields.MAPPING)) {
            var field_1 = leaveType.getField(LeaveType_1.LeaveTypeFields.MAPPING);
            var relatedFields = leaveType.getFields(leaveType.columns);
            if (!valid)
                showMessage('Warning', field_1.text.toString() + ' already exists.');
            else {
                if (field_1.text.toString().toLowerCase() !== 'custom') {
                    stack.push(relatedFields.saveState());
                    relatedFields
                        .disable();
                    relatedFields
                        .optional();
                }
                else {
                    var lastState = stack.pop();
                    // restore state
                    if (lastState)
                        relatedFields.setState(lastState);
                }
                return true;
            }
            return false;
        }
        return valid;
    }
    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        validateField: validateField
    };
});
