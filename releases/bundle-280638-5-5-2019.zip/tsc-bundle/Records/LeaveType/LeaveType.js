/**
 * @module      LeaveManagement
 * @class       LeaveType
 * @description LeaveType class extends `BaseModel` class to access the data of Vacation Types in NetSuite.
 * @author      Mohamed Elshowel
 * @version     1.0.0
 * @repo        https://github.com/bahyali/ed-netsuite-leave-management
 * @NApiVersion 2.0
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "../../Core/Model/BaseModel", "../../Core/Validation"], function (require, exports, BaseModel_1, Validation_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    /** Defining the Fields in the Leave Type Record */
    var LeaveTypeFields;
    (function (LeaveTypeFields) {
        LeaveTypeFields["MAPPING"] = "mapping";
        LeaveTypeFields["DAYS_LIMIT"] = "days_limit";
        LeaveTypeFields["MAX_DAYS_REQUEST"] = "max_days_request";
        LeaveTypeFields["FREQUENT_TYPE"] = "freq_type";
        LeaveTypeFields["FREQUENT_VALUE"] = "freq_value";
        LeaveTypeFields["ACCEPT_PAST_DATE"] = "accept_past_date";
    })(LeaveTypeFields = exports.LeaveTypeFields || (exports.LeaveTypeFields = {}));
    var LeaveType = /** @class */ (function (_super) {
        __extends(LeaveType, _super);
        function LeaveType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.recordType = 'customrecord_edc_vac_type';
            _this.columnPrefix = 'custrecord_edc_vac_type_';
            _this.typeMap = {
                'mapping': BaseModel_1.ColumnType.LIST,
                'days_limit': BaseModel_1.ColumnType.NUMBER,
                'max_days_request': BaseModel_1.ColumnType.NUMBER,
                'freq_type': BaseModel_1.ColumnType.LIST,
                'freq_value': BaseModel_1.ColumnType.NUMBER,
                'accept_past_date': BaseModel_1.ColumnType.BOOLEAN,
            };
            _this.columns = Object.keys(_this.typeMap);
            _this.validation = {
                'mapping': [isCustom],
                'max_days_request': [
                    { lessThanOrEqual: ['days_limit'] }
                ],
                'days_limit': [
                    { greaterThanOrEqual: ['max_days_request'] }
                ]
            };
            return _this;
        }
        return LeaveType;
    }(BaseModel_1.BaseModel));
    exports.LeaveType = LeaveType;
    /* =====================[ CUSTOMIZED FUNCTIONS ]=====================  */
    // Function to check if the `Mapping` Field has a value of 'Custom' or 
    var isCustom = function (field, model) {
        if (field.text.toString().toLowerCase() !== 'custom') {
            // call isUnique Validator
            return Validation_1.Validation.isUnique(field, model)();
        }
        return true;
    };
});
