/**
 * @NScriptName ClientScript Permission
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(["require", "exports", "N/runtime", "./Permission", "../helpers"], function (require, exports, runtime, Permission_1, helpers_1) {
    function pageInit(context) {
        var permission = new Permission_1.Permission().createFromRecord(context.currentRecord);
        var allowedPermissionHours = 2;
        var today = new Date();
        // Previous Approved permissions this month.
        var previousPermissions = new Permission_1.Permission()
            .where(Permission_1.PermissionField.EMPLOYEE, '==', runtime.getCurrentUser().id)
            .where(Permission_1.PermissionField.STATUS, '==', helpers_1.ApprovalStatus.APPROVED)
            .where(Permission_1.PermissionField.DATE, 'after', today.setDate(0))
            .find([Permission_1.PermissionField.PERIOD]);
        var takenPeriod = 0;
        if (previousPermissions) {
            for (var i = 0; i < previousPermissions.length; i++) {
                takenPeriod += helpers_1.Model.convertPeriodStrToMins(previousPermissions[i][Permission_1.PermissionField.PERIOD]);
            }
        }
        var reaminingPeriodField = permission.getField(Permission_1.PermissionField.REMAINING_PERIOD);
        if (takenPeriod <= allowedPermissionHours) {
            reaminingPeriodField.value = allowedPermissionHours - takenPeriod;
        }
    }
    function validateField(context) {
        var permission = new Permission_1.Permission().createFromRecord(context.currentRecord);
        var field = permission.getField(permission.removePrefix(context.fieldId));
        if (field._id == Permission_1.PermissionField.FROM || field._id == Permission_1.PermissionField.TO) {
            var remainingPeriodField = permission.getField(Permission_1.PermissionField.REMAINING_PERIOD);
            var remainingPeriod = helpers_1.Model.convertPeriodStrToMins(remainingPeriodField.value);
            var requestPeriod = calculatePeriod(permission);
            if (!remainingPeriod || requestPeriod > remainingPeriod) {
                helpers_1.UI.showMessage('Warning', 'Do not have enough period for permission');
                return false;
            }
            permission.getField(Permission_1.PermissionField.PERIOD).value = helpers_1.Model.convertMinsToText(requestPeriod);
            permission.getField(Permission_1.PermissionField.REMAINING_PERIOD).value = helpers_1.Model.convertMinsToText(remainingPeriod - requestPeriod);
        }
        return true;
    }
    function calculatePeriod(permission) {
        var from = new Date(permission.getField(Permission_1.PermissionField.FROM).value.toString());
        var to = new Date(permission.getField(Permission_1.PermissionField.TO).value.toString());
        return helpers_1.Model.millisecondsToHuman(to.getTime() - from.getTime()).minutes;
    }
    return {
        pageInit: pageInit,
        validateField: validateField,
    };
});
