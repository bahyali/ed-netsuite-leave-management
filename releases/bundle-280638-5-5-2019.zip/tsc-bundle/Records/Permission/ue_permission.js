/**
 * @NScriptName UserEvent Permission
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(["require", "exports", "./Permission", "../helpers", "../LeaveRule/LeaveRule"], function (require, exports, Permission_1, helpers_1, LeaveRule_1) {
    function beforeLoad(context) {
        if (context.type !== context.UserEventType.CREATE)
            return;
        var permission = new Permission_1.Permission().createFromRecord(context.newRecord);
        var leaveRule = permission.relations
            .leaveRule(Number(permission.getField('subsidiary').value))
            .first(['internalid']);
        if (leaveRule) {
            //permission.getField('vac_rule').value = 
            var subsidiaryRuleId = leaveRule.getField('internalid').value;
            var allowedPermissionHours = new LeaveRule_1.LeaveRule()
                .setRecord(subsidiaryRuleId)
                .getField(LeaveRule_1.LeaveRuleField.PERMISSION_HOURS).value;
            permission.getField('allowed_hours').value = allowedPermissionHours;
            var today = new Date();
            // Previous Approved permissions this month.
            var previousPermissions = new Permission_1.Permission()
                // .where(PermissionField.EMPLOYEE, '==', runtime.getCurrentUser().id)
                .where(Permission_1.PermissionField.STATUS, '==', helpers_1.ApprovalStatus.APPROVED)
                // .where(PermissionField.DATE, 'after', today.setDate(0))
                .find([Permission_1.PermissionField.PERIOD]);
            var takenPeriod = 0;
            if (previousPermissions) {
                for (var i = 0; i < previousPermissions.length; i++) {
                    takenPeriod += helpers_1.Model.convertPeriodStrToMins(previousPermissions[i][Permission_1.PermissionField.PERIOD]);
                }
            }
            var reaminingPeriodField = permission.getField(Permission_1.PermissionField.REMAINING_PERIOD);
            if (takenPeriod <= allowedPermissionHours) {
                reaminingPeriodField.value = allowedPermissionHours - takenPeriod;
            }
        }
    }
    return {
        beforeLoad: beforeLoad,
    };
});
