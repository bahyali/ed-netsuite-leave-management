var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "../LeaveBalance/LeaveBalance", "../../Core/Model/BaseModel"], function (require, exports, LeaveBalance_1, BaseModel_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var Employee = /** @class */ (function (_super) {
        __extends(Employee, _super);
        function Employee() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.recordType = 'employee';
            _this.typeMap = {
                'jobtitle': BaseModel_1.ColumnType.STRING,
                'subsidiary': BaseModel_1.ColumnType.LIST,
                'supervisor': BaseModel_1.ColumnType.LIST,
                'department': BaseModel_1.ColumnType.LIST,
            };
            _this.relations = {
                vacationBalance: function (model, year) {
                    var idField = model._record.getValue('id');
                    return new LeaveBalance_1.LeaveBalance().where('emp_name', '==', idField)
                        .where('year', '==', year);
                }
            };
            return _this;
        }
        return Employee;
    }(BaseModel_1.BaseModel));
    exports.Employee = Employee;
});
