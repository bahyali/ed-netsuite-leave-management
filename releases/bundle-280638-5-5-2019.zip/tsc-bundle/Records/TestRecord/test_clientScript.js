/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(["require", "exports", "N/runtime", "./TestRecord"], function (require, exports, runtime, TestRecord_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var leave = 1;
    function pageInit(context) {
        new TestRecord_1.TestRecord();
        leave++;
        return runtime.accountId;
    }
    exports.pageInit = pageInit;
});
