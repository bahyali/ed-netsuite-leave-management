define(["require", "exports"], function (require, exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var SuperTestRecord = /** @class */ (function () {
        function SuperTestRecord() {
            this.lel = 0;
        }
        return SuperTestRecord;
    }());
    exports.SuperTestRecord = SuperTestRecord;
});
