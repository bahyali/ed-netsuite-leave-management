/**
 * @module      LeaveManagement
 * @class       LeaveBalance
 * @description LeaveBalance class extends `BaseModel` class to access the data of Leave Balances in NetSuite.
 * @author      Mohamed Elshowel
 * @version     1.0.0
 * @repo        https://github.com/bahyali/ed-netsuite-leave-management
 * @NApiVersion 2.0
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "../../Core/Model/BaseModel", "../../Core/Model/QueryBuilder"], function (require, exports, BaseModel_1, QueryBuilder_1) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var LeaveBalanceField;
    (function (LeaveBalanceField) {
        LeaveBalanceField["EMPLOYEE"] = "emp_name";
        LeaveBalanceField["YEAR"] = "year";
        LeaveBalanceField["SUBSIDIARY"] = "subsidiary";
        LeaveBalanceField["JOBTITLE"] = "jobtitle";
        LeaveBalanceField["SUPERVISOR"] = "supervisor";
        LeaveBalanceField["DEPARTMENT"] = "department";
        LeaveBalanceField["ANNUAL"] = "annual";
        LeaveBalanceField["TRANSFERRED"] = "transferred";
        LeaveBalanceField["REPLACEMENT"] = "replacement";
        LeaveBalanceField["CASUAL"] = "casual";
        LeaveBalanceField["SICK"] = "sick";
        LeaveBalanceField["UNPAID"] = "unpaid";
    })(LeaveBalanceField = exports.LeaveBalanceField || (exports.LeaveBalanceField = {}));
    var LeaveBalance = /** @class */ (function (_super) {
        __extends(LeaveBalance, _super);
        function LeaveBalance() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.recordType = 'customrecord_edc_emp_vac_balance';
            _this.columnPrefix = 'custrecord_edc_vac_balance_';
            // Mapping
            _this.typeMap = {
                //fieldName: fieldType
                "year": QueryBuilder_1.ColumnType.STRING,
                "emp_name": QueryBuilder_1.ColumnType.LIST,
                "subsidiary": QueryBuilder_1.ColumnType.LIST,
                "jobtitle": QueryBuilder_1.ColumnType.STRING,
                "department": QueryBuilder_1.ColumnType.LIST,
                "supervisor": QueryBuilder_1.ColumnType.LIST,
                "transferred": QueryBuilder_1.ColumnType.NUMBER,
                "annual": QueryBuilder_1.ColumnType.NUMBER,
                "replacement": QueryBuilder_1.ColumnType.NUMBER,
                "total_regular": QueryBuilder_1.ColumnType.NUMBER,
                "unpaid": QueryBuilder_1.ColumnType.NUMBER,
                "casual": QueryBuilder_1.ColumnType.NUMBER,
                "sick": QueryBuilder_1.ColumnType.NUMBER,
            };
            _this.columns = Object.keys(_this.typeMap);
            return _this;
        }
        return LeaveBalance;
    }(BaseModel_1.BaseModel));
    exports.LeaveBalance = LeaveBalance;
});
