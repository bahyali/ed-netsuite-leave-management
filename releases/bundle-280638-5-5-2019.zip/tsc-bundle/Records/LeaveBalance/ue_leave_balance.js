/**
 * @NScriptName UserEvent - Vacation Balance
 * @NApiVersion 2.0
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(["require", "exports"], function (require, exports) {
    function beforeLoad(context) {
        // let leaveBalance = new LeaveBalance();
        //
        // let record = context.newRecord;
        //
        // let currentUser = runtime.getCurrentUser();
        //
        // let recordEmployeeId = record.getValue({'fieldId': 'custrecord_edc_vac_balance_emp_name'});
        //
        // let isAllowed = [
        //     currentUser.id == recordEmployeeId
        // ];
        //
        // if (!isAllowed.every(value => value))
        //     throw error.create({
        //         name: "EDC_MSG_INSUFFICIENT_PERMISSION",
        //         message: "Sorry, You do not have permission to view this record."
        //     });
    }
    return {
        beforeLoad: beforeLoad
    };
});
