define(["require", "exports", "N/ui/message"], function (require, exports, UIMessage) {
    Object.defineProperty(exports, "__esModule", { value: true });
    var ApprovalStatus;
    (function (ApprovalStatus) {
        ApprovalStatus[ApprovalStatus["PENDING_APPROVAL"] = 1] = "PENDING_APPROVAL";
        ApprovalStatus[ApprovalStatus["APPROVED"] = 2] = "APPROVED";
        ApprovalStatus[ApprovalStatus["REJECTED"] = 3] = "REJECTED";
    })(ApprovalStatus = exports.ApprovalStatus || (exports.ApprovalStatus = {}));
    var PeriodFrequentType;
    (function (PeriodFrequentType) {
        PeriodFrequentType["Days"] = "days";
        PeriodFrequentType["Months"] = "months";
        PeriodFrequentType["Years"] = "years";
        PeriodFrequentType["Lifetime"] = "lifetime";
    })(PeriodFrequentType = exports.PeriodFrequentType || (exports.PeriodFrequentType = {}));
    var UI;
    (function (UI) {
        function showMessage(title, message, duration, type) {
            if (duration === void 0) { duration = 5000; }
            if (type === void 0) { type = UIMessage.Type.WARNING; }
            UIMessage.create({
                title: title,
                message: message,
                type: type
            }).show({ duration: duration });
        }
        UI.showMessage = showMessage;
    })(UI = exports.UI || (exports.UI = {}));
    var Model;
    (function (Model) {
        function resultToObject(result, prefix) {
            if (prefix === void 0) { prefix = ''; }
            var response = {};
            if (result.columns)
                result.columns.forEach(function (column) {
                    response[column.name.replace(prefix, '')] = result.getValue(column.name);
                });
            return response;
        }
        Model.resultToObject = resultToObject;
        function millisecondsToHuman(number) {
            return {
                'seconds': number / 1000,
                'minutes': number / (1000 * 60),
                'hours': number / (1000 * 60 * 60),
                'days': number / (1000 * 60 * 60 * 24)
            };
        }
        Model.millisecondsToHuman = millisecondsToHuman;
        function toNSDateString(date) {
            return (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
        }
        Model.toNSDateString = toNSDateString;
        function getWorkingDays(startDate, endDate, weekEnds, holidays) {
            if (weekEnds === void 0) { weekEnds = [5, 6]; }
            if (holidays === void 0) { holidays = []; }
            var result = 0;
            var currentDate = startDate;
            while (currentDate <= endDate) {
                var weekDay = currentDate.getDay();
                if (weekEnds.indexOf(weekDay) == -1
                    &&
                        holidays.filter(function (holiday) { return holiday.toDateString() == currentDate.toDateString(); }).length == 0)
                    result++;
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return result;
        }
        Model.getWorkingDays = getWorkingDays;
        function convertPeriodStrToMins(periodString) {
            var actualPeriod = 0;
            var periodStrArray = periodString.split(' ');
            if (periodStrArray[0][1]) { // Hours don't have [0][1]
                actualPeriod = Number(periodStrArray[0]);
            }
            else {
                actualPeriod = Number(periodStrArray[0]) * 60;
                if (periodStrArray[3]) { // Not Just an Hour ,but also have minutes (&)
                    actualPeriod += Number(periodStrArray[3]);
                }
            }
            return actualPeriod;
        }
        Model.convertPeriodStrToMins = convertPeriodStrToMins;
        /** @param period Number of minutes to be converted */
        function convertMinsToText(period) {
            var periodStr;
            if (period >= 60) {
                var hours = Math.floor(period / 60);
                var minutes = period - (hours * 60);
                periodStr = hours + ' hour';
                if (hours > 1)
                    periodStr += 's';
                if (minutes) {
                    periodStr += ' & ' + minutes + ' minutes';
                }
            }
            else {
                periodStr = period + ' minutes';
            }
            return periodStr;
        }
        Model.convertMinsToText = convertMinsToText;
    })(Model = exports.Model || (exports.Model = {}));
});
